import sqlite3

# Создаем подключение к базе данных
connection = sqlite3.connect("mydatabase.db")

# Создаем курсор
cursor = connection.cursor()

# Выполняем SQL-запрос для извлечения данных из таблицы "users"
cursor.execute("SELECT * FROM users")

# Извлекаем результаты запроса
result = cursor.fetchall()

# Выводим результаты запроса
for row in result:
    print("ID:", row[0])
    print("Username:", row[1])
    print("Email:", row[2])

# Закрываем соединение
connection.close()