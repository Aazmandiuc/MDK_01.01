import sqlite3

# Создаем подключение к базе данных
connection = sqlite3.connect("mydatabase.db")

# Создаем курсор для выполнения SQL-запросов
cursor = connection.cursor()

# Вставляем данные в таблицу "users"
cursor.execute("INSERT INTO users (username, email) VALUES (?, ?)", ("user1", "user1@mail.ru"))
cursor.execute("INSERT INTO users (username, email) VALUES (?, ?)", ("user2", "user2@maik.ru"))

# Вставляем данные в таблицу "posts"
cursor.execute("INSERT INTO posts (title, content, user_id) VALUES (?, ?, ?)", ("Заголовок поста 1", "Содержание поста 1", 1))
cursor.execute("INSERT INTO posts (title, content, user_id) VALUES (?, ?, ?)", ("Заголовок поста 2", "Содержание поста 2", 2))

# Сохраняем изменения и закрываем соединение
connection.commit()
connection.close()
