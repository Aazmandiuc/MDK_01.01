import sys
import sqlite3
from PyQt6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QLabel, QPushButton, QTextEdit

class DatabaseViewer(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Просмотр БД")

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        layout = QVBoxLayout()

        self.text_edit = QTextEdit()
        layout.addWidget(self.text_edit)

        self.load_button = QPushButton("Загрузить данные")
        layout.addWidget(self.load_button)

        self.central_widget.setLayout(layout)

        self.load_button.clicked.connect(self.load_data)

    def load_data(self):
        connection = sqlite3.connect("mydatabase.db")
        cursor = connection.cursor()

        cursor.execute("SELECT * FROM users")
        result = cursor.fetchall()

        data_text = ""
        for row in result:
            data_text += f"ID: {row[0]}\n"
            data_text += f"Username: {row[1]}\n"
            data_text += f"Email: {row[2]}\n\n"

        self.text_edit.setPlainText(data_text)

        connection.close()

def main():
    app = QApplication(sys.argv)
    window = DatabaseViewer()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
