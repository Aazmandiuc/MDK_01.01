import sqlite3

# Создаем подключение к базе данных (или создаем новую, если она не существует)
connection = sqlite3.connect("mydatabase.db")

# Создаем курсор для выполнения SQL-запросов
cursor = connection.cursor()

# Создаем таблицу "users"
cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    username TEXT NOT NULL,
                    email TEXT NOT NULL
                )''')

# Создаем таблицу "posts"
cursor.execute('''CREATE TABLE IF NOT EXISTS posts (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    content TEXT,
                    user_id INTEGER,
                    FOREIGN KEY (user_id) REFERENCES users (id)
                )''')
# Сохраняем изменения и закрываем соединение
connection.commit()
connection.close()
