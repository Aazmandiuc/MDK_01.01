import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QM
from user1_window import WindowForUser1
from user2_window import WindowForUser2

class PasswordWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Авторизация")
        self.setGeometry(100, 100, 300, 150)

        layout = QVBoxLayout()

        self.username_label = QLabel("Имя пользователя:")
        self.username_input = QLineEdit()
        self.password_label = QLabel("Пароль:")
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)

        self .login_button = QPushButton("Войти")
        self.login_button.clicked.connect(self.check.password)

        layout.addWidget(self. username_label)
        layout.addWidget(self.username_input)
        layout.addWidget(self.password_label)
        layout.addWidget(self.password_input)
        layout.addWidget(self.login_button)

        self.setLayout(layout)

    def check_password(self):
        username = self.username_input.text()
        password = self.password_input.text()

        if username == "user1" and password == "password1":
            self.open_windowl()
        elif username == "user2" and password == "password2":
            self.open_window2()
        else:
            self.show_error_message(title: "Ошибка авторизации",
                                    message: "Неверное имя пользователя илипароль.")

    def open_window1(self):
        # Здесь вы можете создать и отобразить окно для пользователя 1
        self.close()
        window = WindowForUser1()
        window.show()

    def open_window2(self):
        # Здесь вы можете создать и отобразить окно для пользователя 2
        self.close()
        window = WindowForUser2()
        window.show()

    def show_error_message(self, title, message):
        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Icon.Critical)
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.exec()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_window = PasswordWindow()
    main_window.show()
    sys.exit(app.exec())





























