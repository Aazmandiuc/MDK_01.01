from PyQt6.QtWidgets import QWidget, QDialog


class WindowForUser1(QWidget):
    def __init__(self):
        super().__init__()
        new_window = QDialog(self)
        new_window.setWindowTitle('Окно для пользователя 1')
        new_window.setGeometry(200, 200, 300, 150)
        # Отображаем новое окно
        new_window.exec()