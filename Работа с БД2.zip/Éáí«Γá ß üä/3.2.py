import sys
import sqlite3
from PyQt6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QLabel, QPushButton, QTableWidget, QTableWidgetItem

class DatabaseViewer(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Просмотр БД")

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        layout = QVBoxLayout()

        self.table_widget = QTableWidget()
        layout.addWidget(self.table_widget)

        self.load_button = QPushButton("Загрузить данные")
        layout.addWidget(self.load_button)

        # Добавляем 2-ю кнопку
        self.load_button = QPushButton("Загрузить вторые данные")
        layout.addWidget(self.load_button)# надо изменить привязку(?)

        self.central_widget.setLayout(layout)

        self.load_button.clicked.connect(self.load_data)
        
        '''self.table_widget = QTableWidget()
        self.table_widget.resize(200, 400)
        self.table_widget.setWindowTitle('второе окно')

        connection = sqlite3.connect("mydatabase.db")
        cursor = connection.cursor()'''
        
    def load_data(self):
        connection = sqlite3.connect("mydatabase.db")
        cursor = connection.cursor()

        cursor.execute("SELECT * FROM users")
        result = cursor.fetchall()
        
        self.table_widget.setRowCount(len(result))
        self.table_widget.setColumnCount(len(result[0]))

        # Задаем заголовки столбцов
        column_headers = [description[0] for description in cursor.description]
        self.table_widget.setHorizontalHeaderLabels(column_headers)

        # Заполняем таблицу данными
        for row_index, row_data in enumerate(result):
            for column_index, cell_data in enumerate(row_data):
                item = QTableWidgetItem(str(cell_data))
                self.table_widget.setItem(row_index, column_index, item)

        connection.close()

def main():
    app = QApplication(sys.argv)
    window = DatabaseViewer()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
