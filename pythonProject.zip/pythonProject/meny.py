import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QMenuBar, QMenu, QMessageBox
from PyQt6.QtGui import QAction

class MyWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setGeometry(100, 100, 600, 400)
        self.setWindowTitle('Программа с меню')

# Создаём MenyBar (полосу меню)
        menubar = self.menuBar()

# Создаём меню "Файл"
        file_meny = menubar.addMenu('Файл')

        # Создаём действия для меню "Файл"
        open_action = QAction('Открыть', self)
        save_action = QAction('созранить', self)
        exit_action = QAction('Вфход', self)
        exit_action.triggered.connect(self.close)

# Добавим действия в меню "Файл"
        file_meny.addAction(open_action)
        file_meny.addAction(save_action)
        file_meny.addSeparator()
        file_meny.addAction(exit_action)

# Создём меню "Вид"
        View_menu = menubar.addMenu('Вид')

        # Создаём действие для меню "Вид"
        toggle_action = QAction('показать./скрыть', self, checkable=True)
        toggle_action.setChecked(True)
        toggle_action.triggered.connect(self.toggleText)

# Добавляем действие в меню "Вид"









