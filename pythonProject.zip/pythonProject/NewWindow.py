import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QPushButton, QDialog

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.initUI()

    def initUI(self):
        self.setWindowTitle('Главное окно')
        self.setGeometry(100, 100, 400, 200)

        # Создаём кнопку для открытия нового окна
        self.button = QPushButton('Открыть новое окно', self)
        self.button.setGeometry(100, 80, 200, 40)
        self.button.clicked.connect(self.openNewWinsow)

    def openNewWinsow(self):
        #создаём новое окно (диалоговое окно)
        new_window = QDialog(self)
        new_window.setWindowTitle('Новое окно')
        new_window.setGeometry(200, 200, 300, 150)

        # Отображаем новое окно
        new_window.exec()

def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()